<!--===========================Coppy All Code And Paste in index file for new channel add-->




  <div class="col-6 col-sm-4 col-md-3 col-lg-2">
        <a href="play.html?rana&maxpro="><div class="card">
            <img src="./content/img/channel_icons/sabtvhd.png">
            <div class="info">
                <span class="channel_name bg-dark  h6 ps-2 px-2">Sab-TV HD</span>
                <span  class="channel_category bg-danger text-light h6 ps-2 px-2">Entertainment</span>
            </div></a>
    </div></div>
